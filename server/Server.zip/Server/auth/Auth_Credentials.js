module.exports = {
  // Auth Credentials - Do not see it :)
  CLIENT_ID:
    "233499940483-meii3809v5fclps0hb23fve7h50gsmk0.apps.googleusercontent.com",
  CLIENT_SECRET: "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",
  REDIRECT_URI: "https://developers.google.com/oauthplayground",
  REFRESH_TOKEN:
    "1//048YlxPWIN_8dCgYIARAAGAQSNwF-L9IrB6ZCyotDrAGvWEH-u0SDnVbDpp141nbhywrQiirQH9tK1AQlwY2NReQVAlkV8shq3qw",
};
