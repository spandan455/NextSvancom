const express = require("express");
const app = express();
const port = process.env.PORT || 80;

// Middleware
app.use(express.json());
app.use(require("./router/auth"));
app.use(require("./router/pages"));

// Start Server
app.listen(port, () => {
  console.log(`Server Started on Port http://localhost:${port}`);
});
