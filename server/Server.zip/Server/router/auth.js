const express = require("express");
const router = express.Router();
const Credentials = require("../auth/Auth_Credentials");
const nodemailer = require("nodemailer");
let handlebars = require("handlebars");
const { google } = require("googleapis");
let fs = require("fs");

// oAuth Client to Send Mails
const oAuth2Client = new google.auth.OAuth2(
  Credentials.CLIENT_ID,
  Credentials.CLIENT_SECRET,
  Credentials.REDIRECT_URI
);
oAuth2Client.setCredentials({ refresh_token: Credentials.REFRESH_TOKEN });

// Set Template and Compliw Mail
const compileHtml = (path, callback) => {
  fs.readFile(path, { encoding: "utf-8" }, function (err, html) {
    if (err) {
      callback(err);
      throw err;
    } else {
      callback(null, html);
    }
  });
};

// Send Contact Mail
router.post("/SendContactMail", (req, res) => {
  const { username, email, phone, subject, msg } = req.body;
  console.log(username);

  const sendMail = async () => {
    const accessToken = await oAuth2Client.getAccessToken();

    compileHtml(
      "C:/Users/MANDAR/Desktop/Mayank/Coding/server/emails/contactMail.html",
      function (err, html) {
        let template = handlebars.compile(html);

        let replacements = {
          username: username,
          email: email,
          phone: phone,
          subject: subject,
          msg: msg,
        };
        let mailTemplate = template(replacements);

        let transporter = nodemailer.createTransport({
          service: "gmail",
          auth: {
            type: "OAuth2",
            user: "mayanknavare@gmail.com",
            clientId: Credentials.CLIENT_ID,
            clientSecret: Credentials.CLIENT_SECRET,
            refreshToken: Credentials.REFRESH_TOKEN,
            accessToken: accessToken,
          },
        });

        let mailOptions = {
          from: "Mayank Navare <mayanknavare@gmail.com>",
          to: "spandanjambhekar123@gmail.com",
          // to: "varshaa.ssti@gmail.com",
          subject: "New Customer Contact",
          html: mailTemplate,
          text: `from,\n${username}\nEmail: ${email}\nContact No. ${phone}\n\nSubject\n${subject}\n\nMessage\n${msg}`,
        };

        transporter.sendMail(mailOptions);
      }
    );
  };

  sendMail()
    .then(() => {
      return res.status(200).send("Contact Email Sent!");
    })
    .catch((err) => {
      console.log(err);
      return res.status(400).send("Something Went Wrong!");
    });
});

// send Feedback Mail
router.post("/SendFeedbackMail", (req, res) => {
  const { username, email, stars, review } = req.body;

  // Email Sending
  const sendMail = async () => {
    const accessToken = await oAuth2Client.getAccessToken();

    compileHtml(
      "C:/Users/MANDAR/Desktop/Mayank/Coding/server/emails/feedbackMail.html",
      function (err, html) {
        let template = handlebars.compile(html);

        let replacements = {
          username: username,
          email: email,
          stars: stars,
          review: review,
        };
        let mailTemplate = template(replacements);

        let transporter = nodemailer.createTransport({
          service: "gmail",
          auth: {
            type: "OAuth2",
            user: "mayanknavare@gmail.com",
            clientId: Credentials.CLIENT_ID,
            clientSecret: Credentials.CLIENT_SECRET,
            refreshToken: Credentials.REFRESH_TOKEN,
            accessToken: accessToken,
          },
        });

        let mailOptions = {
          from: "Mayank Navare <mayanknavare@gmail.com>",
          to: "spandanjambhekar123@gmail.com",
          // to: "varshaa.ssti@gmail.com",
          subject: "Customer Review",
          html: mailTemplate,
          text: `${username} rated Svancom!\nEmail: ${email}\n\nRated\n${stars} stars\n\nReviewed\n${review}`,
        };

        transporter.sendMail(mailOptions);
      }
    );
  };

  sendMail()
    .then(() => {
      return res.status(200).send("Feedback Email Sent!");
    })
    .catch((err) => {
      console.log(err);
      return res.status(400).send("Something Went Wrong!");
    });
});

module.exports = router;
