const express = require("express");
const router = express.Router();

// Pages
router.get("/", (req, res) => {
  res.send(`Hello world from Server`);
});

module.exports = router;
